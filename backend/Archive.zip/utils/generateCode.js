// utils/generateCode.js
export function generateRandomCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
